import os, re, uuid, json, subprocess, threading, time
from pathlib import Path
from flask import Flask, request, render_template_string, send_from_directory, jsonify

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024
ROOT=Path(__file__).parent
DATA=Path(os.getenv("DATA_DIR","data"))
UPLOADS=DATA/"uploads"; OUTPUTS=DATA/"clips"
UPLOADS.mkdir(parents=True,exist_ok=True); OUTPUTS.mkdir(parents=True,exist_ok=True)
JOBS={}
LOCK=threading.Lock()

PAGE=r"""
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>AutoClip AI</title><style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#080d1b;color:#f5f7ff;font-family:Inter,Arial,sans-serif}
main{max-width:920px;margin:35px auto;padding:20px}.brand{color:#a7b5ff;font-weight:800;letter-spacing:2px}
h1{font-size:clamp(34px,7vw,58px);line-height:1.02;margin:18px 0}p{color:#aeb9d4;line-height:1.6}.panel{background:#121b31;border:1px solid #2c3b60;border-radius:22px;padding:24px;margin-top:24px}
label{display:block;margin:17px 0 8px;color:#e3e9ff;font-weight:600}input,select{width:100%;padding:14px;border-radius:11px;border:1px solid #3b4b70;background:#0a1327;color:white}
button{margin-top:22px;padding:15px 22px;border:0;border-radius:12px;background:#8fa2ff;color:#081027;font-weight:800;font-size:16px;cursor:pointer;width:100%}
button:disabled{opacity:.5}.grid{display:grid;grid-template-columns:1fr 1fr;gap:15px}.hint{font-size:13px;color:#8f9fbe}.status{margin-top:18px;white-space:pre-wrap;color:#c2ceff}.clip{padding:15px 0;border-top:1px solid #34415f}.clip a{color:#aab8ff}.tag{display:inline-block;border:1px solid #45577f;border-radius:99px;padding:6px 10px;color:#b7c5ff;font-size:12px}
@media(max-width:600px){.grid{grid-template-columns:1fr}main{margin:12px auto}}
</style></head><body><main><div class="brand">AUTOCLIP AI</div><span class="tag">FREE OPEN-SOURCE MVP</span>
<h1>Turn long videos into short clips.</h1>
<p>Upload a video or paste a supported public video link. AutoClip finds speech-rich moments and exports vertical clips for Shorts, Reels and TikTok.</p>
<div class="panel"><form id="form">
<label>Video URL (optional if uploading)</label><input name="url" type="url" placeholder="Paste a supported public video URL">
<label>Or upload a video file</label><input name="video" type="file" accept="video/*">
<div class="grid"><div><label>Clip duration</label><select name="duration"><option value="30">30 seconds</option><option value="45" selected>45 seconds</option><option value="60">60 seconds</option></select></div>
<div><label>Number of clips</label><select name="count"><option>3</option><option selected>5</option><option>8</option></select></div></div>
<label>Source type</label><select name="source_type"><option value="video">Recorded video</option><option value="live">Live stream (record first, then clip)</option></select>
<div id="livebox" style="display:none"><label>Record live stream for (minutes)</label><select name="live_minutes"><option value="5">5 minutes</option><option value="10" selected>10 minutes</option><option value="15">15 minutes</option><option value="30">30 minutes</option></select><p class="hint">The stream is recorded for the selected time, then clips are generated. This is not instant clipping while the stream is live.</p></div>
<button id="go">Create my clips</button><div class="status" id="status"></div><div id="results"></div>
</form></div>
<p class="hint">Only process videos you own or have permission to download and edit. URL support depends on the source platform, its terms, access restrictions and server resources. Private, DRM-protected and login-only content is not supported.</p>
</main><script>
const form=document.getElementById('form'),status=document.getElementById('status'),results=document.getElementById('results'),btn=document.getElementById('go'),type=document.querySelector('[name=source_type]'),live=document.getElementById('livebox');
type.addEventListener('change',()=>live.style.display=type.value==='live'?'block':'none');
form.addEventListener('submit',async e=>{e.preventDefault();btn.disabled=true;results.innerHTML='';status.textContent='Submitting job…';
try{const r=await fetch('/api/jobs',{method:'POST',body:new FormData(form)});const j=await r.json();if(!r.ok)throw Error(j.error||'Could not start job');status.textContent='Job started. Processing…';
let done=false;while(!done){await new Promise(x=>setTimeout(x,3000));const s=await fetch('/api/jobs/'+j.id);const d=await s.json();status.textContent=d.message||d.status;if(d.status==='done'){done=true;results.innerHTML=d.clips.map(c=>`<div class="clip"><b>${c.name}</b> · ${c.duration}s<br><a href="${c.url}">Download MP4</a></div>`).join('');}else if(d.status==='error'){throw Error(d.error||'Processing failed');}}
}catch(err){status.textContent='Error: '+err.message;}finally{btn.disabled=false;}});
</script></body></html>"""

def run(cmd, timeout=None):
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
    if p.returncode: raise RuntimeError((p.stderr or p.stdout)[-2200:])
    return p.stdout

def transcribe(path):
    from faster_whisper import WhisperModel
    model=WhisperModel(os.getenv("WHISPER_MODEL","base"),device="cpu",compute_type="int8")
    segs,_=model.transcribe(str(path),vad_filter=True)
    return [{"start":s.start,"end":s.end,"text":s.text.strip()} for s in segs]

def select_windows(transcript,total,duration,count):
    candidates=[]
    step=max(8,duration//3)
    for start in range(0,max(1,int(total-duration)+1),step):
        end=min(total,start+duration)
        text=" ".join(s["text"] for s in transcript if s["start"]<end and s["end"]>start)
        wc=len(re.findall(r"\w+",text))
        if wc<8: continue
        emphasis=sum(text.lower().count(k) for k in ["amazing","secret","important","best","never","how","why","mistake","money","love","लेकिन","क्यों"])
        candidates.append((wc+4*emphasis,start,end))
    candidates.sort(reverse=True); picked=[]
    for score,start,end in candidates:
        if all(abs(start-p[1])>duration*.7 for p in picked): picked.append((score,start,end))
        if len(picked)>=count: break
    if not picked and total>0:
        for i in range(min(count,max(1,int(total//duration)+1))):
            start=min(i*duration,max(0,total-duration)); picked.append((0,start,min(total,start+duration)))
    return picked

def process_job(job_id, source_path, duration, count, live=False):
    with LOCK: JOBS[job_id].update(status="processing",message="Preparing video and transcribing audio…")
    try:
        if live:
            # live source is recorded for the requested time, then the resulting file is clipped
            pass
        meta=json.loads(run(["ffprobe","-v","quiet","-print_format","json","-show_format",str(source_path)]))
        total=float(meta["format"]["duration"])
        transcript=transcribe(source_path)
        windows=select_windows(transcript,total,duration,count)
        clips=[]
        for i,(_,start,end) in enumerate(windows,1):
            out=OUTPUTS/f"{job_id}_clip_{i}.mp4"
            run(["ffmpeg","-y","-ss",str(start),"-i",str(source_path),"-t",str(end-start),"-vf","scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2","-c:v","libx264","-preset","veryfast","-crf","24","-c:a","aac","-b:a","128k","-movflags","+faststart",str(out)])
            clips.append({"name":f"Clip {i}","duration":round(end-start),"url":f"/clips/{out.name}"})
        with LOCK: JOBS[job_id].update(status="done",message="Your clips are ready!",clips=clips)
    except Exception as e:
        with LOCK: JOBS[job_id].update(status="error",message="Processing failed",error=str(e))
    finally:
        try: Path(source_path).unlink(missing_ok=True)
        except Exception: pass

@app.get("/")
def home(): return render_template_string(PAGE)

@app.post("/api/jobs")
def create_job():
    url=request.form.get("url","").strip()
    upload=request.files.get("video")
    source_type=request.form.get("source_type","video")
    if not url and (not upload or not upload.filename): return jsonify(error="Add a URL or upload a video."),400
    job=uuid.uuid4().hex[:12]; duration=int(request.form.get("duration",45)); count=min(8,max(1,int(request.form.get("count",5))))
    with LOCK: JOBS[job]={"status":"queued","message":"Job queued"}
    if upload and upload.filename:
        path=UPLOADS/f"{job}_{Path(upload.filename).name}"
        upload.save(path)
        threading.Thread(target=process_job,args=(job,path,duration,count,False),daemon=True).start()
    else:
        path=UPLOADS/f"{job}.mp4"
        live_minutes=int(request.form.get("live_minutes",10)) if source_type=="live" else None
        def download_and_process():
            try:
                with LOCK: JOBS[job].update(status="downloading",message="Downloading / recording source…")
                cmd=["yt-dlp","--no-playlist","-f","bv*+ba/b","--merge-output-format","mp4","-o",str(path)]
                if source_type=="live":
                    cmd += ["--live-from-start","--downloader","ffmpeg","--downloader-args",f"ffmpeg_i:-t {live_minutes*60}"]
                cmd.append(url)
                run(cmd,timeout=(live_minutes*60+900 if live_minutes else 3600))
                candidates=list(UPLOADS.glob(job+"*"))
                if not candidates: raise RuntimeError("Downloader did not create a video file. This URL may not be supported.")
                actual=candidates[0]
                process_job(job,actual,duration,count,source_type=="live")
            except Exception as e:
                with LOCK: JOBS[job].update(status="error",message="Could not process source",error=str(e))
        threading.Thread(target=download_and_process,daemon=True).start()
    return jsonify(id=job)

@app.get("/api/jobs/<job>")
def job_status(job):
    with LOCK: data=JOBS.get(job)
    if not data: return jsonify(error="Job not found"),404
    return jsonify(data)

@app.get("/clips/<path:filename>")
def get_clip(filename): return send_from_directory(OUTPUTS,filename,as_attachment=True)

@app.get("/health")
def health(): return {"ok":True}

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","5000")))
