# AutoClip AI — public deployment starter

## Deploy publicly (Render)
1. Create a GitHub account and a new public or private repository.
2. Upload the files in this folder to the repository.
3. Create a Render account and choose **New → Blueprint**.
4. Connect the repository; Render reads `render.yaml` and builds the Docker image.
5. After deployment, open the `onrender.com` URL. Add a custom domain in Render if desired.

A paid persistent disk is configured because video files and generated clips need storage. Compute, disk, bandwidth and hosting may incur charges. This is not a guaranteed zero-cost public hosting setup.

## Local run
Requires Python 3.11+ and FFmpeg.
```bash
pip install -r requirements.txt
python app.py
```
Open http://localhost:5000

## What works
- Upload recorded video files.
- Download a public URL supported by yt-dlp, subject to the platform's restrictions.
- Speech transcription with Faster-Whisper (first run downloads its model).
- Select speech-rich time windows and export vertical MP4 clips.
- Live URL mode attempts to record a bounded segment, then generates clips after recording.

## Important limits
- "Any link" cannot be guaranteed: platforms change access rules, block downloads, require login, or use DRM.
- Live mode is **record-then-clip**, not instant rolling clipping while the stream is live.
- Moment selection is a simple speech-density heuristic, not a sophisticated viral-moment model.
- A public service needs moderation, quotas, authentication, rate limits, cleanup policies and job queue infrastructure before broad launch.
- Only process content you own or are authorized to download and edit. Respect copyright and the platform's terms.
- Hosting this publicly costs money for compute, storage and bandwidth; this package does not publish itself or create a domain.
